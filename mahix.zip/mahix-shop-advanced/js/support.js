
import {toast} from './app.js';
document.addEventListener('DOMContentLoaded',()=>{document.querySelector('#supportForm')?.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(e.currentTarget);if(!d.get('contact')||!d.get('message')){toast('همه فیلدها را تکمیل کن.');return}toast('فرم آماده اتصال به سیستم تیکتینگ است؛ هنوز روی سرور ارسال نمی‌شود.');e.currentTarget.reset()});document.querySelector('#thumbnailForm')?.addEventListener('submit',e=>{e.preventDefault();toast('درخواست طراحی در این نسخه فقط نمایشی است و ثبت سروری نمی‌شود.');e.currentTarget.reset()})});
