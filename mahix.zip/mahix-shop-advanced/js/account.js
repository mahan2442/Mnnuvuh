
import {toast} from './app.js';
document.addEventListener('DOMContentLoaded',()=>{document.querySelector('#demoLogin')?.addEventListener('submit',e=>{e.preventDefault();toast('ورود واقعی پس از راه‌اندازی سرویس احراز هویت فعال می‌شود.')});document.querySelector('#demoRegister')?.addEventListener('submit',e=>{e.preventDefault();toast('ثبت‌نام نمایشی است؛ حسابی روی سرور ساخته نشد.')})});
