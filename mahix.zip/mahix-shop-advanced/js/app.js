
export const money = n => new Intl.NumberFormat('fa-IR').format(n) + ' تومان';
export const fa = n => new Intl.NumberFormat('fa-IR').format(n);
export function toast(message){const el=document.querySelector('#toast');if(!el)return;el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3000)}
export function getCart(){try{return JSON.parse(localStorage.getItem('mahix-cart')||'[]')}catch{return []}}
export function saveCart(cart){localStorage.setItem('mahix-cart',JSON.stringify(cart));updateCartCount()}
export function updateCartCount(){const el=document.querySelector('#cartCount');if(el)el.textContent=fa(getCart().length)}
export async function loadProducts(){const local=localStorage.getItem('mahix-products');if(local){try{return JSON.parse(local)}catch{}}const r=await fetch('data/products.json');return r.json()}
export function initCommon(){updateCartCount();document.querySelectorAll('[data-cart-open]').forEach(b=>b.addEventListener('click',()=>document.querySelector('#cartModal')?.classList.add('open')));document.querySelectorAll('[data-modal-close]').forEach(b=>b.addEventListener('click',()=>b.closest('.modal')?.classList.remove('open')))}

document.addEventListener('DOMContentLoaded',initCommon);
